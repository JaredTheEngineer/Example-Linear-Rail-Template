
#define DEBUG 1 // This turns the serial debug feature ON/OFF. 0 = OFF, 1 = ON. Essentially makes it easier to debug issues. Turning off can sometimes speed up processing, but should have much effect on yours, so Id leave on. 
//==================(debugln)=============//

#if DEBUG == 1
        #define debug(x) Serial.print(x);
        #define debug_delay(x) delay(x);
        #define debugln(x) Serial.println(x)
#else
        #define debug(x)
        #define debug_delay(x)
        #define debugln(x)
#endif
