//These are the libraries used
#include "SpeedSettings.h"
#include "DEBUG.h"
#include <AccelStepper.h> //version 1.61

// Define NON-stepper connections
#define forwardLimitSwitch    2
#define rearLimitSwitch    3

//Define stepper connections and setup AccelStepper
#define stepperDIR 7
#define stepperPulsePin 8
#define stepperEnablePin 9

//this assigns the pins to the accelStepper library
AccelStepper stepper(1, stepperPulsePin, stepperDIR); // Driver; PUL pin 6; DIR pin 9

//define the homing states and set to notHomed initially. Use the "error" as a kill status
const int notHomed = 0;
const int homed = 1;
const int error = 3;
const int pressedDuringHome = 4;
int homeStatus = notHomed;

//this is used so some of the debug readings dont run continiously
const int runSequence = 4;
int debugStatus = notHomed;

// Interrupt handlers
void rearLimitHit (){

        if(homeStatus != pressedDuringHome){    
                delay(20);
                if(digitalRead(rearLimitSwitch) == LOW){
                        //if it is homing and trigger the rear limit, set to homed
                        if(homeStatus == notHomed){
                             homeStatus = pressedDuringHome;
                             debugln("rear limit hit #2");
                        }
                        //if its already homed and triggers the rear limit, something is wrong, stop and require a reset.
                        if(homeStatus == homed){
                             digitalWrite(stepperEnablePin, HIGH);   
                             homeStatus = error;
                             debugln("rear limit hit #3");
                        }
                }
        }
  
}
void forwardLimitHit (){

         delay(20);
        if(digitalRead(forwardLimitSwitch) == LOW){
                    //this is set to "error" since this limit should never be hit. If it is, it will stop and require a reset of the Arduino. 
                    digitalWrite(stepperEnablePin, HIGH);
                    homeStatus = error;
                    debugln("forward limit hit");
        }
}

//Setup 
void customSetup() {
        //These turn on the serial monitor, prints to let the user know, and delays 500ms before the process begins. 
        Serial.begin(9600);
        debugln("System ON");
        delay(500);
        
        // Setup the Hall Effect switches as Inputs
        pinMode(forwardLimitSwitch, INPUT_PULLUP);
        pinMode(rearLimitSwitch, INPUT_PULLUP);

        pinMode(stepperEnablePin, OUTPUT);
        
        // Attach interrupt pins to handlers (functions can be found on this page above)
        attachInterrupt(digitalPinToInterrupt(forwardLimitSwitch), forwardLimitHit, FALLING);
        attachInterrupt(digitalPinToInterrupt(rearLimitSwitch), rearLimitHit, FALLING);

        //AccelStepper setup stuff
        stepper.setEnablePin(4);
        stepper.setPinsInverted(false, false, true);
        stepper.setMaxSpeed(stepperMaxSpeed); // 60RPM = 1 rev/sec = microsteps setting/maxspeed
        stepper.setAcceleration(stepperHomeAcceleration); // (was 6400)1 rev to maxspeed = microsteps setting/2 = acceleration; 1 rev =microsteps setting/2 = moveto
        stepper.setSpeed(stepperHomeSpeed);
}
