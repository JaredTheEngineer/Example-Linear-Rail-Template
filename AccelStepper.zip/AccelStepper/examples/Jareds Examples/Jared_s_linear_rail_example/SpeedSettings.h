//I walkthrough this code in this video: 

//MAIN DISTANCE SETTINGS
        float stepsToGetOffLimitSwitchDuringHoming = 600;    //This is used to back off of the rear limit during homing. Test real world and adjust to the offset that you want.
        float homeTravelDistance = 30000;                    //This sets a high number for homing the device. If the homing sequence doesnt reach the rear limit switch, increase this number.
        float runDistance = 5500;                           //This set the length of the run so we dont have to use the limit switches (and they can be used as stops). Test this and adjust until the desired travel distance is reached.
        
//MAIN SPEED SETTINGS
        
        float stepperHomeSpeed = 2000;                       //Homing speed. Higher # = faster homing
        float stepperHomeAcceleration = 1000;                //Home Acceleration
        
        float stepperForwardRunSpeed = 5000;                 //This sets the speed at which the stepper will push the weight at. larger# = faster
        float stepperForwardRunAcceleration = 2000;          //Sets the acceleration for the forward movement (pushing the weights) larger = faster
        
        float stepperRearRunSpeed = 5000;                    //This sets the speed at which the stepper will return the sled to the home position at. 
        float stepperRearRunAcceleration = 2000;             //Sets the acceleration for the rear movement back to home position. larger = faster

//SECONDARY SETTINGS (NOT LIKELY TO BE CHANGE)
        
        float stepperMaxSpeed = 10000;                       //This is for future use. Not super useful now. But if you ever set your speed higher than this, adjust this to match.
        const int delayWhileWaitingOnWeightsToReturn = 100;  //this is incase you want a delay to wait for the weights to return to zero position. Set to "0" if not.
