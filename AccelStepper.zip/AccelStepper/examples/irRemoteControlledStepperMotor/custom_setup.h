        // Livewire Bait Ripper
        // Copyright (C) 2022 Mike Donovan
        // v 1.1 2022/01/05
        #include <AccelStepper.h>
        #include<IRremote.h>
        
        // Define a stepper motor and the pins it will use
        AccelStepper stepper(1, 6, 9); // Driver; PUL pin 6; DIR pin 9
        
        // Define IR
        int IRPIN = 11; // IRreceiver Pin 11
        IRrecv irrecv(IRPIN); //Reads the signals from receiver
        decode_results results; //saves decoded results
        
        // Define variables
        long p1 = 2400;
        long p2 = 4800;
        long p3 = 7200;
        long s1 = 1000000;
        long s2 = 2800;

        //setup for state changes (to hold inside of sequences)
        int state;
        
        const int on_and_waiting = 1; 
        const int case_A = 2;
        const int case_B = 3;
        const int case_C = 4;
        const int increasing_speed = 5;
        const int decreasing_speed = 6; 
        const int signal_recieved = 7;
        const int forward = 8;
        const int reverse = 9;

        int caseA_state = forward;

        //setup for enable/dissable state tracking (good to have for later on conditional codework)
        int enable_state = 10;
        const int enabled = 11;
        const int disabled = 12; 

        const int test = 1;
        long count;
        //Jared's Remote:
//        const unsigned long keypad1 = ;// 
//        const unsigned long keypad1 = 16724175;// 
//        const unsigned long keypad1 = 16724175;// 
//        const unsigned long keypad1 = 16724175;// 
